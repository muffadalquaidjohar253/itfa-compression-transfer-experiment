# File Storage, Compression and Backup Investigation

**Project EF101-P17 (EF-101, Fall 2026)** - an experimental investigation of how file type affects storage size, compression, transfer speed and backup.

## Team

| Name | Roll number |
|---|---|
| Mufaddal | EE-231 |
| Abeer | EE-243 |
| Khizer | EE-235 |

## What this project investigates

1. **Compression:** 12 test files of different types (text, document, bitmap, JPEG, PNG, raw audio, MP3, video, PDF, ZIP, 7z) were ZIP-compressed (lossless). For each file we recorded the original size, compressed size, size reduction (%) and compression ratio.
2. **Transfer speed:** a 3,500 MB test set was copied from the laptop to a USB drive and to an SD card, and the time and throughput were measured.
3. **Data integrity:** SHA-256 hashes were recorded for all files before and after the copy.
4. **Backup:** a 3-2-1 backup plan for a hypothetical student, and an explanation of how backup differs from synchronization.

## Key results (as recorded in the report)

| Measurement | Result |
|---|---|
| Transfer to USB drive | 3,500 MB in 250.04 s = **13.9977 MB/s** |
| Transfer to SD card | 3,500 MB in 483.19 s = **7.2435 MB/s** |
| Speed difference | USB was about 1.9 times faster than the SD card |
| ZIP size reduction, all 12 files | between -0.040% and -0.001% (the ZIP was slightly larger than each original) |
| Before vs after hashes | identical for all 24 files (see `data/data_integrity.csv`) |

![Transfer throughput](charts/transfer_throughput.png)

## Repository contents

| Path | What it holds |
|---|---|
| [`report/`](report/) | The full written report (DOCX and PDF) |
| [`data/`](data/) | Every table from the report as a CSV file |
| [`charts/`](charts/) | Transfer throughput chart and ZIP size-reduction chart |
| [`docs/compression_analysis.md`](docs/compression_analysis.md) | Lossless vs lossy compression, why some files compress more, limitations of the test files |
| [`docs/transfer_analysis.md`](docs/transfer_analysis.md) | USB vs SD card throughput and why they differ |
| [`docs/backup_and_synchronization.md`](docs/backup_and_synchronization.md) | Backup vs synchronization, the 3-2-1 rule and the student backup plan |

### Data files

| File | Table in the report |
|---|---|
| `data/compression_results.csv` | Compression and file experiment (sizes, reduction %, ratio) |
| `data/transfer_speed.csv` | Speed and throughput (USB and SD card) |
| `data/hashes_before_transfer.csv` | SHA-256 of every file before transfer |
| `data/hashes_after_transfer.csv` | SHA-256 and size in bytes after transfer |
| `data/data_integrity.csv` | Before and after hashes side by side, with a match column |
| `data/backup_vs_synchronization.csv` | Comparison of synchronization and backup |
| `data/student_backup_plan.csv` | Where each of the three copies lives in the student plan |

## Where each requirement of the brief is covered

| Requirement | Where |
|---|---|
| At least 12 test files of different types | `data/compression_results.csv` |
| Original size of every file | `data/compression_results.csv` |
| Compress with a standard lossless tool (ZIP) | `report/`, `data/compression_results.csv` |
| Compression ratio and percentage size reduction | `data/compression_results.csv`, `charts/compression_size_reduction.png` |
| Why text/BMP differ from JPEG/MP3/video | `docs/compression_analysis.md` |
| Large copy with time and throughput | `data/transfer_speed.csv`, `docs/transfer_analysis.md` |
| Two storage media compared | USB drive vs SD card, `charts/transfer_throughput.png` |
| Hashes before and after the copy | `data/hashes_before_transfer.csv`, `data/hashes_after_transfer.csv`, `data/data_integrity.csv` |
| Backup plan for a hypothetical student | `docs/backup_and_synchronization.md` |
| Backup vs synchronization | `docs/backup_and_synchronization.md` |
| Lossless vs lossy, and why repeated compression gives little benefit | `docs/compression_analysis.md` |
| 3-2-1 backup interpretation | `docs/backup_and_synchronization.md` |

## Limitations

These come from the report itself:

- The test files were created with `WriteAllBytes` using generated binary data, not normal application content. A `.jpg`, `.mp3` or `.bmp` extension alone does not make a valid media file, so the results measure additional ZIP compression of generated data. They do not show how real JPEG, MP3 or video files behave. Repeating the experiment with genuine files would give a more meaningful comparison.
- The dataset was transferred without encryption.

## Checking a file hash yourself

On Windows, PowerShell:

```powershell
Get-FileHash .\1_large_text.txt -Algorithm SHA256
```

or Command Prompt:

```
certutil -hashfile 1_large_text.txt SHA256
```

Run the same command on the copy on the USB drive. If the two hashes are identical, the file arrived unchanged.

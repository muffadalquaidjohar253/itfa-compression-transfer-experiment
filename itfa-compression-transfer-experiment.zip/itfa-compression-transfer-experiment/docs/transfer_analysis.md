# Transfer speed analysis

The same 3,500 MB test set was copied from the laptop to a USB drive and to an SD card. Raw numbers: [`data/transfer_speed.csv`](../data/transfer_speed.csv).

![Transfer throughput](../charts/transfer_throughput.png)

## Speed and Throughput

| PRIMARY DEVICE | SECONDARY DEVICE | MBs  | SECONDS | THROUGHPUT (MB/S) |
|----------------|------------------|------|---------|-------------------|
| Laptop         | USB              | 3500 | 250.04  | 13.9977           |

| PRIMARY DEVICE | SECONDARY DEVICE | MBs  | SECONDS | THROUGHPUT (MB/S) |
|----------------|------------------|------|---------|-------------------|
| Laptop         | SD Card          | 3500 | 483.19  | 7.2435            |

The speed and throughput are higher for the USB drive than for the SD card. The likely reasons are:

1.  THE ROAD IS WIDER (INTERFACE AND BUS SPEED): The USB drive and port usually use a faster interface (for example USB 3.x) than the SD card and its reader, so more data can move per second. Think of the USB drive as a 4-lane highway and the SD card as a single-lane dirt road.

2.  WORKING IN TEAMS (CONTROLLER AND FLASH CHIPS): A USB drive usually has a controller that writes to several flash chips at the same time, like several workers sharing the job, while an SD card typically has fewer or slower chips, like a single worker doing all the work. The write speed of the flash itself therefore differs between the two.

3.  SUSTAINED WRITES SLOW DOWN: Both devices write fast at first because of a small cache, but once the cache fills, the speed falls to the real write speed of the flash memory. A 3,500 MB transfer is large enough to fill the cache, so the slower device falls behind more.

4.  HEAT (A MINOR FACTOR): Devices can slow down when they get hot (thermal throttling), and a small SD card may warm up more than a larger USB drive. This can contribute, but it is not the main reason for the difference.

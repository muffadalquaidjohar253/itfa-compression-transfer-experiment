# Backup and synchronization

## Backup vs Synchronization

| **Feature**                | **Data Synchronization**                                                                                       | **Data Backup**                                                                                  |
|----------------------------|----------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------|
| **Primary Purpose**        | Keeps files identical across multiple devices in real-time so you can work seamlessly anywhere.                | Creates historical, point-in-time snapshots to recover data after loss, deletion, or corruption. |
| **File Deletion Behavior** | **Two-way sync:** If you delete or corrupt a file locally, it gets deleted/corrupted in the cloud immediately. | **One-way archive:** Deleting a local file does not delete the saved backup copies.              |
| **Version History**        | Usually limited or temporary (e.g., standard trash bin for 30 days).                                           | Retains long-term historical versions (e.g., daily or weekly snapshots over months/years).       |
| **Common Examples**        | Google Drive, OneDrive, Dropbox, iCloud.                                                                       | Mac Time Machine, Windows File History, Veeam, Backblaze.                                        |

Synchronization helps us in accessibility while backup helps us to recover lost data. Relying only on cloud sync is dangerous because if a virus encrypts a file locally, the synced versions will also get encrypted

## 3-2-1 Backup Rule

The 3-2-1 backup rule is used by many IT professionals for data preservation. It states that there should be 3 copies of data in 2 different storage types and 1 off-site location.

The 3 copies of data are stored as

**Copy 1:** On my primary device (laptop’s internal SSD)

**Copy 2:** A local backup stored in a USB

**Copy 3:** An office backup stored in a different location (cloud storage)

The 2 different storage types are

Type 1: Laptop internal SSD (working copy)

Type 2: External USB drive or external hard drive (local backup storage)

The off-site copy is saved in cloud storage.

## Hypothetical Student Backup Plan

We design this hypothetical backup plan for a student so that they never lose their assignment, projects and data

If a student’s laptop gets stolen or faces a hardware issue or accidently deletes the file, this backup plan helps the student recover their data.

<u>STUDENT PROFILE</u>

**<u>FILE TYPES:</u>** A student generally has projects, assignments, PDF slides and lecture details

**<u>STORAGE REQUIRED:</u>** As academic text and files do not take much space, 50GB to 100GB is enough

**<u>HARDWARE USED</u>**: A standard laptop

<u>APPLYING THE 3-2-1 RULE</u>

**COPY 1:** (Working copy)

WHERE IT LIVES: In the internal SSD of the laptop

PURPOSE: Daily active work

**COPY 2:** (Local External Backup)

WHERE IT LIVES: In a separate USB drive

PURPOSE: Fast recovery if the files get deleted

**COPY 3:** (Off-site Cloud Copy)

WHERE IT LIVES: Cloud storage

PURPOSE: Off-site protection in case of damage to laptop or theft

<u>BACKUP WORKFLOW</u>

**COPY 1:** The working copy gets updated as the student is doing their work simultaneously

**COPY 2:** Once every week the student plugs in their local external drive, and copies their desired data into that drive

COPY 3: An independent cloud backup is created automatically on a schedule or through a cloud service with retained file versions. A synchronized folder alone is not sufficient because deletions and corrupted files may also synchronize.

- If the laptop is stolen or damaged, the retained cloud backup can restore the data. If the internet is unavailable, the disconnected local backup provides another recovery option. Recovery should be tested periodically.

<u>TABLE</u>

| **Requirement**     | **Implementation in Student Plan**               | **Storage Type**              |
|---------------------|--------------------------------------------------|-------------------------------|
| **Primary Data**    | Laptop Internal SSD (C:\Users\Student\Documents) | Solid-State Storage           |
| **Local Backup**    | External 1 TB Hard Drive plugged in weekly       | Magnetic HDD / External Flash |
| **Off-site Backup** | Google Drive / OneDrive versioned cloud backup   | Cloud Server Infrastructure   |

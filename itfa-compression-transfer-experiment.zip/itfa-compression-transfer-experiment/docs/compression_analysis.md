# Compression analysis

Results table: [`data/compression_results.csv`](../data/compression_results.csv). Chart: [`charts/compression_size_reduction.png`](../charts/compression_size_reduction.png).

![ZIP size reduction per file](../charts/compression_size_reduction.png)

## Limitations of the test files

The test files were created using WriteAllBytes with generated binary data rather than normal application content. Their filenames have extensions such as .jpg, .mp3 and .bmp, but these extensions alone do not make them valid media files. This limits what our experiment can conclude about real JPEG, MP3, video and image compression. For a meaningful file-format comparison, the experiment should be repeated with genuine files that can be opened by their corresponding applications.

## Why Some Files Reduce More Than Others

In the recorded results, the ZIP output is slightly larger than the input for all 12 files, so no measured file has a positive size reduction. The extra bytes can come from archive headers and other ZIP metadata. This does not establish that real text and BMP files compress poorly, because the generated binary test files may not contain the normal patterns of those formats. With genuine files, repetitive plain text and uncompressed BMP images often compress substantially, while JPEG, MP3, MP4 and existing ZIP/7z archives generally gain little from another lossless compression pass. The actual result depends on the content, not merely the filename extension.

**LOSSY AND LOSSLESS COMPRESSION**

Lossless compression reduces file size without removing information. When decompressed, the recovered data is exactly the same as the original. ZIP and 7-Zip use lossless compression, so the ZIP test in this project measures whether each file can be packed more efficiently without changing its contents. PNG is also a lossless image format; a DOCX file normally uses ZIP-based packaging.

Lossy compression makes media smaller by permanently discarding some information that is considered less noticeable or less essential. JPEG images and MP3 audio commonly use lossy compression; MP4 video usually contains video encoded with lossy methods, although the exact codec and settings matter. Once information has been discarded, decompressing the file does not reconstruct the original bit-for-bit.

Important distinction: putting an already lossy JPEG or MP3 into a ZIP archive is still a lossless ZIP operation. ZIP does not apply new JPEG or MP3 quality loss. Because those media files have usually already been compressed, ZIP may save very little space and can even make the archive slightly larger due to overhead.

Connection to our results: all recorded size reductions are negative, meaning the ZIP archives grew slightly. We therefore cannot claim that the text or BMP reduced by 99.9%. The table tests additional ZIP compression, not the amount of original quality lost when a JPEG, MP3 or video was created. A separate lossy-quality experiment would require encoding genuine images/audio/video at different quality settings and comparing their size and quality.

Calculation: Size reduction (%) = \[(original size − ZIP archive size) ÷ original size\] × 100. Compression ratio = original size ÷ ZIP archive size. A negative size reduction means an increase in size; a ratio below 1:1 indicates that the compressed archive is larger than the original.
